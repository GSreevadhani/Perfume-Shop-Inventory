/**
 * 
 */
/**
 * 
 */
module Collections {
	requires java.sql;
}